fetch('http://localhost:3000/products')
  .then(res => res.json())
  .then(data => {
    let html = '';
    data.forEach(p => {
      html += `
        <div class="card">
          <h3>${p.title}</h3>
          <p>Price: ${p.price}</p>
          <button>Add to Cart</button>
        </div>
      `;
    });
    document.getElementById('product-list').innerHTML = html;
  });