let cart = JSON.parse(localStorage.getItem("cart")) || [];
let table = document.getElementById("cartTable");
let grandTotal = 0;

cart.forEach((item, index) => {
  let total = item.price * item.quantity;
  grandTotal += total;

  let row = table.insertRow();
  row.innerHTML = `
    <td>${item.title}</td>
    <td>Rs ${item.price}</td>
    <td>${item.quantity}</td>
    <td>Rs ${total}</td>
    <td><button onclick="removeItem(${index})">❌</button></td>
  `;
});

document.getElementById("grandTotal").innerText =
  "Grand Total: Rs " + grandTotal;

function removeItem(index) {
  cart.splice(index, 1);
  localStorage.setItem("cart", JSON.stringify(cart));
  location.reload();
}

function checkout() {
  if (cart.length === 0) {
    alert("Cart is empty!");
  } else {
    alert("Order placed successfully!");
    localStorage.removeItem("cart");
    window.location.href = "orders.html";
  }
}